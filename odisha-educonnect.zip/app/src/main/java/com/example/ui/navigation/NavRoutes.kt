package com.example.ui.navigation

import kotlinx.serialization.Serializable

@Serializable
sealed class Screen {
    @Serializable
    data object Home : Screen()
    
    @Serializable
    data class SubjectList(val categoryId: String, val categoryName: String) : Screen()
    
    @Serializable
    data class ChapterList(val subjectId: String, val subjectName: String) : Screen()
    
    @Serializable
    data class NoteDetail(val noteId: String, val noteTitle: String) : Screen()
    
    @Serializable
    data object QuizList : Screen()
    
    @Serializable
    data class QuizPlayer(val quizId: String, val quizTitle: String) : Screen()
    
    @Serializable
    data object Bookmarks : Screen()
    
    @Serializable
    data object Profile : Screen()
    
    @Serializable
    data object ExamUpdates : Screen()

    @Serializable
    data object Settings : Screen()
}
