package com.example.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.CategoryEntity
import com.example.data.local.SubjectEntity
import com.example.data.repository.EducationRepository
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

class EducationViewModel(private val repository: EducationRepository) : ViewModel() {

    val categories: StateFlow<List<CategoryEntity>> = repository.getCategories()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun getSubjects(categoryId: String): StateFlow<List<SubjectEntity>> = 
        repository.getSubjects(categoryId)
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun getChapters(subjectId: String) = repository.getChapters(subjectId)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun getNotes(chapterId: String) = repository.getNotes(chapterId)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val bookmarks = repository.getBookmarks()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun toggleBookmark(noteId: String, isBookmarked: Boolean) {
        viewModelScope.launch {
            repository.toggleBookmark(noteId, isBookmarked)
        }
    }

    val quizzes = repository.getQuizzes()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
}
