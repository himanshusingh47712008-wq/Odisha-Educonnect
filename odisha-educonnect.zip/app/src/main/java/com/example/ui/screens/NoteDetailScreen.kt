package com.example.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.BookmarkBorder
import androidx.compose.material.icons.filled.Download
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.NoteEntity

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun NoteDetailScreen(
    noteTitle: String,
    notes: List<NoteEntity>,
    onBookmarkToggle: (NoteEntity) -> Unit,
    onDownloadPdf: (NoteEntity) -> Unit,
    onBack: () -> Unit
) {
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(noteTitle) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .padding(padding)
                .fillMaxSize(),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            items(notes) { note ->
                NoteItem(
                    note = note,
                    onBookmarkToggle = { onBookmarkToggle(note) },
                    onDownloadPdf = { if (note.isPdf) onDownloadPdf(note) }
                )
            }
        }
    }
}

@Composable
fun NoteItem(
    note: NoteEntity,
    onBookmarkToggle: () -> Unit,
    onDownloadPdf: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = note.title,
                    fontWeight = FontWeight.Bold,
                    fontSize = 20.sp,
                    modifier = Modifier.weight(1f)
                )
                Row {
                    IconButton(onClick = onBookmarkToggle) {
                        Icon(
                            imageVector = if (note.isBookmarked) Icons.Default.Bookmark else Icons.Default.BookmarkBorder,
                            contentDescription = "Bookmark"
                        )
                    }
                    if (note.isPdf) {
                        IconButton(onClick = onDownloadPdf) {
                            Icon(Icons.Default.Download, contentDescription = "Download PDF")
                        }
                    }
                }
            }
            Spacer(modifier = Modifier.height(8.dp))
            if (note.isPdf) {
                Text(
                    "This note is available as a PDF.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.secondary
                )
                Button(
                    onClick = onDownloadPdf,
                    modifier = Modifier.padding(top = 8.dp)
                ) {
                    Text("View / Download PDF")
                }
            } else {
                Text(
                    text = note.content,
                    style = MaterialTheme.typography.bodyLarge
                )
            }
        }
    }
}
