package com.example.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(
    onBack: () -> Unit
) {
    var isDarkMode by remember { mutableStateOf(false) }
    var selectedLanguage by remember { mutableStateOf("English") }
    var notificationsEnabled by remember { mutableStateOf(true) }
    var showDownloadDialog by remember { mutableStateOf(false) }

    if (showDownloadDialog) {
        AlertDialog(
            onDismissRequest = { showDownloadDialog = false },
            title = { 
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.HelpOutline, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                    Spacer(Modifier.width(8.dp))
                    Text("Download Help") 
                }
            },
            text = { 
                Column {
                    Text(
                        "Agar aapko 'Generate APK' button nahi dikh raha hai, toh ye check karein:",
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(Modifier.height(8.dp))
                    Text("1. Screen ke top-right mein ek 'Gear' (⚙️) icon ya 'Settings' likha hoga, usey click karein.")
                    Text("2. Click karne ke baad ek sidebar khulega, wahan 'Export' menu dhoondhein.")
                    Text("3. 'Export' ke andar 'Generate APK' button par click karein.")
                    Text("4. Agar aap mobile browser par hain, toh 'Desktop Site' mode on karke dekhein.")
                    Spacer(Modifier.height(8.dp))
                    Text(
                        "Note: 'Shared App' view mein ye options nahi hote, aapko Project Editor mein jaana hoga.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.error
                    )
                }
            },
            confirmButton = {
                Button(onClick = { showDownloadDialog = false }) {
                    Text("Theek Hai")
                }
            }
        )
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Settings") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .padding(padding)
                .fillMaxSize()
        ) {
            item {
                SettingsHeader("General")
            }
            item {
                SettingsToggleItem(
                    title = "Dark Mode",
                    icon = Icons.Default.DarkMode,
                    checked = isDarkMode,
                    onCheckedChange = { isDarkMode = it }
                )
            }
            item {
                SettingsClickableItem(
                    title = "Language",
                    subtitle = selectedLanguage,
                    icon = Icons.Default.Language,
                    onClick = { /* Handle language selection */ }
                )
            }
            item {
                SettingsToggleItem(
                    title = "Push Notifications",
                    icon = Icons.Default.Notifications,
                    checked = notificationsEnabled,
                    onCheckedChange = { notificationsEnabled = it }
                )
            }
            
            item {
                SettingsHeader("Admin Tools")
            }
            item {
                SettingsClickableItem(
                    title = "Upload PDF Notes",
                    subtitle = "Manage study materials",
                    icon = Icons.Default.CloudUpload,
                    onClick = { /* Admin feature */ }
                )
            }
            item {
                SettingsClickableItem(
                    title = "Add Questions",
                    subtitle = "Update MCQ tests",
                    icon = Icons.Default.AddBox,
                    onClick = { /* Admin feature */ }
                )
            }

            item {
                SettingsHeader("App Management")
            }
            item {
                SettingsClickableItem(
                    title = "Download App (APK)",
                    subtitle = "Install on your mobile device",
                    icon = Icons.Default.GetApp,
                    onClick = { showDownloadDialog = true }
                )
            }
            item {
                SettingsClickableItem(
                    title = "Copy Shared App Link",
                    subtitle = "Share the web version of this app",
                    icon = Icons.Default.Share,
                    onClick = { /* In a real app, use clipboard manager */ }
                )
            }

            item {
                SettingsHeader("About")
            }
            item {
                SettingsClickableItem(
                    title = "Odisha Education Book",
                    subtitle = "Version 1.0.0",
                    icon = Icons.Default.Info,
                    onClick = { }
                )
            }
            item {
                SettingsClickableItem(
                    title = "Privacy Policy",
                    icon = Icons.Default.PrivacyTip,
                    onClick = { }
                )
            }
            item {
                SettingsClickableItem(
                    title = "Terms of Service",
                    icon = Icons.Default.Description,
                    onClick = { }
                )
            }
        }
    }
}

@Composable
fun SettingsHeader(title: String) {
    Text(
        text = title,
        modifier = Modifier.padding(16.dp),
        color = MaterialTheme.colorScheme.primary,
        fontWeight = FontWeight.Bold,
        fontSize = 14.sp
    )
}

@Composable
fun SettingsToggleItem(
    title: String,
    icon: ImageVector,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit
) {
    ListItem(
        headlineContent = { Text(title) },
        leadingContent = { Icon(icon, contentDescription = null) },
        trailingContent = {
            Switch(checked = checked, onCheckedChange = onCheckedChange)
        }
    )
}

@Composable
fun SettingsClickableItem(
    title: String,
    subtitle: String? = null,
    icon: ImageVector,
    onClick: () -> Unit
) {
    ListItem(
        headlineContent = { Text(title) },
        supportingContent = subtitle?.let { { Text(it) } },
        leadingContent = { Icon(icon, contentDescription = null) },
        modifier = Modifier.clickable { onClick() }
    )
}
