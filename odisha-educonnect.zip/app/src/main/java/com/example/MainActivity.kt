package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.toRoute
import androidx.room.Room
import com.example.data.local.EducationDatabase
import com.example.data.repository.EducationRepository
import com.example.ui.navigation.Screen
import com.example.ui.screens.*
import com.example.ui.theme.OdishaEducationHubTheme
import com.example.ui.viewmodel.EducationViewModel

class MainActivity : ComponentActivity() {
    @OptIn(ExperimentalMaterial3Api::class)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        
        val db = Room.databaseBuilder(
            applicationContext,
            EducationDatabase::class.java, "education-db"
        ).build()
        
        val repository = EducationRepository(db.educationDao())
        
        val viewModelFactory = object : ViewModelProvider.Factory {
            override fun <T : ViewModel> create(modelClass: Class<T>): T {
                @Suppress("UNCHECKED_CAST")
                return EducationViewModel(repository) as T
            }
        }

        setContent {
            OdishaEducationHubTheme {
                val navController = rememberNavController()
                val viewModel: EducationViewModel = viewModel(factory = viewModelFactory)
                
                val categories by viewModel.categories.collectAsState()
                
                // Seed local data on launch
                LaunchedEffect(Unit) {
                    com.example.data.local.SampleData.seed(db.educationDao())
                }

                NavHost(navController = navController, startDestination = Screen.Home) {
                    composable<Screen.Home> {
                        HomeScreen(
                            categories = categories,
                            onCategoryClick = { category ->
                                navController.navigate(Screen.SubjectList(category.id, category.name))
                            },
                            onQuizClick = { navController.navigate(Screen.QuizList) },
                            onBookmarksClick = { navController.navigate(Screen.Bookmarks) },
                            onExamUpdatesClick = { navController.navigate(Screen.ExamUpdates) },
                            onSettingsClick = { navController.navigate(Screen.Settings) }
                        )
                    }

                    composable<Screen.Settings> {
                        SettingsScreen(onBack = { navController.popBackStack() })
                    }
                    
                    composable<Screen.SubjectList> { backStackEntry ->
                        val route = backStackEntry.toRoute<Screen.SubjectList>()
                        val subjects by viewModel.getSubjects(route.categoryId).collectAsState()
                        
                        SubjectListScreen(
                            categoryName = route.categoryName,
                            subjects = subjects,
                            onSubjectClick = { subject ->
                                navController.navigate(Screen.ChapterList(subject.id, subject.name))
                            },
                            onBack = { navController.popBackStack() }
                        )
                    }
                    
                    composable<Screen.ChapterList> { backStackEntry ->
                        val route = backStackEntry.toRoute<Screen.ChapterList>()
                        val chapters by viewModel.getChapters(route.subjectId).collectAsState()
                        
                        ChapterListScreen(
                            subjectName = route.subjectName,
                            chapters = chapters,
                            onChapterClick = { chapter ->
                                navController.navigate(Screen.NoteDetail(chapter.id, chapter.name))
                            },
                            onBack = { navController.popBackStack() }
                        )
                    }
                    
                    composable<Screen.NoteDetail> { backStackEntry ->
                        val route = backStackEntry.toRoute<Screen.NoteDetail>()
                        val notes by viewModel.getNotes(route.noteId).collectAsState()
                        
                        NoteDetailScreen(
                            noteTitle = route.noteTitle,
                            notes = notes,
                            onBookmarkToggle = { note ->
                                viewModel.toggleBookmark(note.id, !note.isBookmarked)
                            },
                            onDownloadPdf = { /* Handle PDF */ },
                            onBack = { navController.popBackStack() }
                        )
                    }

                    composable<Screen.QuizList> {
                        val quizzes by viewModel.quizzes.collectAsState()
                        Scaffold(
                            topBar = { TopAppBar(title = { Text("Quizzes") }) }
                        ) { padding ->
                            LazyColumn(modifier = Modifier.padding(padding)) {
                                items(quizzes) { quiz ->
                                    ListItem(
                                        headlineContent = { Text(quiz.title) },
                                        supportingContent = { Text(quiz.description) },
                                        modifier = Modifier.clickable {
                                            navController.navigate(Screen.QuizPlayer(quiz.id, quiz.title))
                                        }
                                    )
                                }
                            }
                        }
                    }

                    composable<Screen.QuizPlayer> { backStackEntry ->
                        val route = backStackEntry.toRoute<Screen.QuizPlayer>()
                        var questions by remember { mutableStateOf(emptyList<com.example.data.local.QuestionEntity>()) }
                        
                        LaunchedEffect(route.quizId) {
                            questions = repository.getQuestions(route.quizId)
                        }
                        
                        QuizPlayerScreen(
                            quizTitle = route.quizTitle,
                            questions = questions,
                            onBack = { navController.popBackStack() }
                        )
                    }

                    composable<Screen.Bookmarks> {
                        val bookmarks by viewModel.bookmarks.collectAsState()
                        Scaffold(
                            topBar = { TopAppBar(title = { Text("Bookmarks") }) }
                        ) { padding ->
                            LazyColumn(modifier = Modifier.padding(padding)) {
                                items(bookmarks) { note ->
                                    ListItem(
                                        headlineContent = { Text(note.title) },
                                        modifier = Modifier.clickable {
                                            navController.navigate(Screen.NoteDetail(note.chapterId, note.title))
                                        }
                                    )
                                }
                            }
                        }
                    }
                    
                    composable<Screen.ExamUpdates> {
                        Scaffold(
                            topBar = { TopAppBar(title = { Text("Exam Updates") }) }
                        ) { padding ->
                            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                                Text("No updates yet.")
                            }
                        }
                    }
                }
            }
        }
    }
}
