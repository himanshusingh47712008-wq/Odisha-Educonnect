package com.example.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "categories")
data class CategoryEntity(
    @PrimaryKey val id: String,
    val name: String,
    val type: String // "+2", "+3", "GK", "Current Affairs"
)

@Entity(tableName = "subjects")
data class SubjectEntity(
    @PrimaryKey val id: String,
    val categoryId: String,
    val name: String,
    val stream: String // "Arts", "Science", "Commerce", "General"
)

@Entity(tableName = "chapters")
data class ChapterEntity(
    @PrimaryKey val id: String,
    val subjectId: String,
    val name: String,
    val order: Int
)

@Entity(tableName = "notes")
data class NoteEntity(
    @PrimaryKey val id: String,
    val chapterId: String,
    val title: String,
    val content: String, // Text or URL to PDF
    val isPdf: Boolean,
    val isBookmarked: Boolean = false
)

@Entity(tableName = "quizzes")
data class QuizEntity(
    @PrimaryKey val id: String,
    val subjectId: String?,
    val title: String,
    val description: String
)

@Entity(tableName = "questions")
data class QuestionEntity(
    @PrimaryKey val id: String,
    val quizId: String,
    val text: String,
    val options: String, // Comma separated or JSON
    val correctAnswerIndex: Int
)
