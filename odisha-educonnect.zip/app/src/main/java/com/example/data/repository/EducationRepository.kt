package com.example.data.repository

import com.example.data.local.*
import kotlinx.coroutines.flow.*

class EducationRepository(
    private val dao: EducationDao
) {
    // Categories
    fun getCategories(): Flow<List<CategoryEntity>> = dao.getAllCategories()

    // Subjects
    fun getSubjects(categoryId: String): Flow<List<SubjectEntity>> = dao.getSubjectsByCategory(categoryId)

    // Chapters
    fun getChapters(subjectId: String): Flow<List<ChapterEntity>> = dao.getChaptersBySubject(subjectId)

    // Notes
    fun getNotes(chapterId: String): Flow<List<NoteEntity>> = dao.getNotesByChapter(chapterId)

    // Bookmarks
    fun getBookmarks(): Flow<List<NoteEntity>> = dao.getBookmarkedNotes()

    suspend fun toggleBookmark(noteId: String, isBookmarked: Boolean) {
        dao.updateBookmark(noteId, isBookmarked)
    }

    // Quizzes
    fun getQuizzes(): Flow<List<QuizEntity>> = dao.getAllQuizzes()

    suspend fun getQuestions(quizId: String): List<QuestionEntity> {
        return dao.getQuestionsForQuiz(quizId)
    }
}
