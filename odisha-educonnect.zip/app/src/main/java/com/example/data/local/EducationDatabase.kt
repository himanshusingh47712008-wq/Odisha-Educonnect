package com.example.data.local

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface EducationDao {
    @Query("SELECT * FROM categories")
    fun getAllCategories(): Flow<List<CategoryEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertCategories(categories: List<CategoryEntity>)

    @Query("SELECT * FROM subjects WHERE categoryId = :categoryId")
    fun getSubjectsByCategory(categoryId: String): Flow<List<SubjectEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSubjects(subjects: List<SubjectEntity>)

    @Query("SELECT * FROM chapters WHERE subjectId = :subjectId ORDER BY `order` ASC")
    fun getChaptersBySubject(subjectId: String): Flow<List<ChapterEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertChapters(chapters: List<ChapterEntity>)

    @Query("SELECT * FROM notes WHERE chapterId = :chapterId")
    fun getNotesByChapter(chapterId: String): Flow<List<NoteEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertNotes(notes: List<NoteEntity>)

    @Query("SELECT * FROM notes WHERE isBookmarked = 1")
    fun getBookmarkedNotes(): Flow<List<NoteEntity>>

    @Query("UPDATE notes SET isBookmarked = :isBookmarked WHERE id = :noteId")
    suspend fun updateBookmark(noteId: String, isBookmarked: Boolean)

    @Query("SELECT * FROM quizzes")
    fun getAllQuizzes(): Flow<List<QuizEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertQuizzes(quizzes: List<QuizEntity>)

    @Query("SELECT * FROM questions WHERE quizId = :quizId")
    suspend fun getQuestionsForQuiz(quizId: String): List<QuestionEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertQuestions(questions: List<QuestionEntity>)
}

@Database(
    entities = [
        CategoryEntity::class,
        SubjectEntity::class,
        ChapterEntity::class,
        NoteEntity::class,
        QuizEntity::class,
        QuestionEntity::class
    ],
    version = 1,
    exportSchema = false
)
abstract class EducationDatabase : RoomDatabase() {
    abstract fun educationDao(): EducationDao
}
