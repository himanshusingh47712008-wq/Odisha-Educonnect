package com.example.data.local

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

object SampleData {
    suspend fun seed(dao: EducationDao) {
        withContext(Dispatchers.IO) {
            val categories = listOf(
                CategoryEntity("cat1", "+2 First Year", "+2"),
                CategoryEntity("cat2", "+2 Second Year", "+2"),
                CategoryEntity("cat3", "+3 First Year", "+3"),
                CategoryEntity("cat4", "+3 Second Year", "+3")
            )
            dao.insertCategories(categories)

            val subjects = listOf(
                SubjectEntity("sub1", "cat1", "Physics", "Science"),
                SubjectEntity("sub2", "cat1", "Political Science", "Arts"),
                SubjectEntity("sub3", "cat1", "Accountancy", "Commerce")
            )
            dao.insertSubjects(subjects)

            val chapters = listOf(
                ChapterEntity("ch1", "sub1", "Units and Measurements", 1),
                ChapterEntity("ch2", "sub1", "Motion in a Straight Line", 2)
            )
            dao.insertChapters(chapters)

            val notes = listOf(
                NoteEntity("n1", "ch1", "Basic Units", "This chapter covers the fundamental units of measurement in Physics.", false),
                NoteEntity("n2", "ch1", "Dimensional Analysis", "Dimensional analysis is used to check the consistency of equations.", false)
            )
            dao.insertNotes(notes)
            
            val quizzes = listOf(
                QuizEntity("q1", "sub1", "Physics Basics", "Test your knowledge of basic physics concepts.")
            )
            dao.insertQuizzes(quizzes)
            
            val questions = listOf(
                QuestionEntity("qn1", "q1", "What is the SI unit of length?", "Meter,Kilogram,Second,Ampere", 0),
                QuestionEntity("qn2", "q1", "Which of these is a derived unit?", "Meter,Second,Newton,Kelvin", 2)
            )
            dao.insertQuestions(questions)
        }
    }
}
